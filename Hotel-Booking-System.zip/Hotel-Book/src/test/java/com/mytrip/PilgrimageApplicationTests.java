package com.mytrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PilgrimageApplicationTests {

	@Test
	void contextLoads() {
	}

}
